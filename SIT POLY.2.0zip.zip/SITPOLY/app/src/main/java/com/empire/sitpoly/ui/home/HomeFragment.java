package com.empire.sitpoly.ui.home;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.empire.sitpoly.R;
import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.IndicatorView.draw.controller.DrawController;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderLayout;
import com.smarteist.autoimageslider.SliderView;


public class HomeFragment extends Fragment {

    private SliderLayout sliderLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        sliderLayout = view.findViewById(R.id.imageSlider);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.FILL);
        sliderLayout.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderLayout.setScrollTimeInSec(1);

        sliderViews();

        TextView aboutinstitute = view.findViewById(R.id.aboutinstitute);
        aboutinstitute.setText("•\tVision\n" +
                "•\tTo be a center of excellence in technical education by using cutting edge technology that produces competent engineers of today and tomorrow to serve the society.\n" +
                "•\tMission\n" +
                "•\tTo impart quality education by implementing state-of- the-art teaching-learning methods to enrich the academic competency, credibility and integrity of the students.\n" +
                "•\tTo facilitate a conducive ambience and infrastructure to develop professional skills and nurture innovation in students.\n" +
                "•\tTo inculcate sensitivity towards society, respect for environment and promote high standards of ethics.\n" +
                "•\tQuality Policy\n" +
                "•\tWe at Sharad Institute of Technology, Polytechnic strive to achieve stakeholder satisfaction by providing quality education and training in science, engineering and technology in a pleasant and disciplined environment through.\n" +
                "•\tInvolvement at all levels\n" +
                "•\tUp gradation of facilities and human resources\n" +
                "•\tCommitment to continual improvement\n");


        TextView chairman = view.findViewById(R.id.chairman);
        chairman.setText("•\tMinister Of State For Public Health & Family Welfare, Medical Education, Food & Drug Administration, Textile, Culture Affairs Government Of Maharashtra.\n" +
                "\n" +
                "•\tMLA – Shirol Constituency\n" +
                "Hon’ble Shri Dr. Rajendra Patil (Yadravkar) A visionary & dynamic leader who is a  founder Chairman of Sharad Institute of Technlogy.\n" +
                "His in depth knowledge in sectors like Sugar Industry, Spinning mills, Banks , Education, Agriculture and Health has helped into financial and material well- being of around 60,000 farmers across 150+ villages.\n" +
                "He is well known personality in the region and holds responsible position in surrounding Industries and co-operative sector as stated below:\n" +
                "•\tIndustrial\n\n" +
                "•\tChairman: Sharad Sahakari Sakhar Karkhana Ltd., Shree Shamrao Patil (Yadravkar) Nagar, Narande Tal- Hatkangale Dist- Kolhapur\n" +
                "•\tChairman: Parvati Co-op Industrial Estate Ltd., Yadrav Tal- Shirol Dist- Kolhapur\n" +
                "•\tVice President: The All India Federation of Co-op Spinning Mills Ltd., New Delhi\n" +
                "•\tDirector: Kolhapur Zilla Shetkari Vinkari Sahakari Soot Girani Ltd.,Yadrav\n" +
                "•\tDirector: Parvati Co-operative Soot Girni Ltd.,Kurundwad.\n" +
                "•\tEducational\n" +
                "•\tChairman: Shree Shamrao Patil (Yadravkar) Educational & Charitable Trust’s.\n" +
                "•\tFinancial\n" +
                "•\tChairman: Yadrav Co-operative Bank Ltd., Yadrav\n" +
                "•\tDirector: Kolhapur District Co-operative Bank Ltd., Kolhapur\n" +
                "\n");
        return view;




    }

    private void sliderViews() {

        for (int i = 0; i<4; i++){

            DefaultSliderView sliderView = new DefaultSliderView(getContext());

            switch (i){

                case 0:
                    sliderView.setImageDrawable(R.drawable.sit);
                    break;
                case 1:
                    sliderView.setImageDrawable(R.drawable.abc);
                    break;
                case 2:
                    sliderView.setImageDrawable(R.drawable.d2);
                    break;
                case 3:
                    sliderView.setImageDrawable(R.drawable.rajendra_patil);
                    break;
            }

            sliderView.setImageScaleType(ImageView.ScaleType.FIT_CENTER);

            sliderLayout.addSliderView(sliderView);




        }
    }
}